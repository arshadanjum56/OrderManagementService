﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace OrderManagementMicroservice.Models
{
    public class Product
    {
        [JsonProperty(PropertyName = "productNumber")]
        public long Productnumber { get; set; }
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        [JsonProperty(PropertyName = "specification")]
        public string Specification { get; set; }

        [JsonProperty(PropertyName = "image")]
        public string Image { get; set; }

        [JsonProperty(PropertyName = "price")]
        public string Price { get; set; }

        

    }
}
