﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace OrderManagementMicroservice.Models
{
    public class Orders
    {
        [JsonProperty(PropertyName = "id")]
        public string id { get; set; }
        [JsonProperty(PropertyName = "products")]
        public List<Product> Products { get; set; } = new List<Product>();
       // public Product[] products { get; set; } = new Product[0];
        [JsonProperty(PropertyName = "createdDate")]
        public string CreatedDate { get; set; }


    }
}
