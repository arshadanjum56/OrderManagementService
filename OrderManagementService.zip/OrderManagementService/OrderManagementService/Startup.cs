﻿using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;


namespace OrderManagementService.API
{
   public partial class Startup
    {
     public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
    }
}
