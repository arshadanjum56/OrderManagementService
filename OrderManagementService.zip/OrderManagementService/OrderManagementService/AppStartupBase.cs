﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace BulkCreateEntitlementSchedular.API
{
    [ExcludeFromCodeCoverage]
    public abstract class AppStartupBase
    {
        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _environment;
        private readonly string _routeApplicationPrefixName;

        protected AppStartupBase(IConfiguration configuration, IHostingEnvironment environment, string routeApplicationPrefixName)
        {
            _configuration = configuration;
            _environment = environment;
            _routeApplicationPrefixName = routeApplicationPrefixName;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            AddWebInfraStructure(services, _configuration);
           // AddCustom(services);
            AddMvc(services);
        }

        [ExcludeFromCodeCoverage]
        public virtual void AddMvc(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1); 
        }

        public void AddWebInfraStructure(IServiceCollection services, IConfiguration configuration)
        {
           // AddLogging(services);
            AddAppConfigurations(services, configuration);
           
        }
        //private void AddLogging(IServiceCollection services)
        //{
        //    services.AddCustomLogging();
        //}

        protected abstract void AddAppConfigurations(IServiceCollection services, IConfiguration configuration);

        protected abstract void AddCustom(IServiceCollection services);

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
          

            UseMvc(app);
        }

        
        public virtual void UseMvc(IApplicationBuilder app)
        {
            app.UseMvc();
        }
    }
}
