﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.FileProviders;
using OrderManagementMicroservice.Models;
using Newtonsoft.Json.Linq;
using System.IO;

namespace OrderManagementMicroservice.Controllers
{
    [Produces("application/json")]
    [Consumes("application/json")]
    [ApiController]
    [Route("api/v1/[Controller]")]
     public class OrderController : ControllerBase
    {
       
        private readonly ILogger<OrderController> _logger;
        private string orderListJsonString = string.Empty;
        private string productListJsonString = string.Empty;
        private string orderListJsonPath = string.Empty;
        private string productListJsonPath = string.Empty;
       private readonly IFileProvider _fileProvider;

        public OrderController(ILogger<OrderController> logger, IFileProvider fileProvider)
        {
            Console.WriteLine("starting");
            _logger = logger;
            _fileProvider = fileProvider;

            Console.WriteLine("Get IFileProvider" + _fileProvider);
        }

       
        

        /// <summary>
        /// Method to get all Orders.
        /// </summary>
        //[ProducesResponseType(StatusCode.Status201Created)]
      //  [ProducesResponseType(typeof(Orders), 200)]
      //  [ProducesResponseType(typeof(Nullable),(401))]
        [HttpGet(Name= "getAllOrdersUsingGET")]
        public IActionResult Get()
        {
            Console.WriteLine("Get records by id Starting");
            var contents = _fileProvider.GetDirectoryContents("Assets");
            string path = contents.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            Console.WriteLine("orderlistfile path for GetAllrecords " +path);
            string orderListJsonPath = Path.Combine(path, @"orderlist.json");
            orderListJsonString = System.IO.File.ReadAllText(orderListJsonPath);
           Console.WriteLine("Get All records Starting" + orderListJsonString);
           var jsonObj = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Orders>>(orderListJsonString);
        Console.WriteLine("Get All records Finished" + jsonObj);
        return Ok(jsonObj);
        }

        /// <summary>
        /// Method to get Order by id.
        /// </summary>
        /// <param name="id"></param> 
      //  [ProducesResponseType(typeof(Orders), 200)]
       // [ProducesResponseType(typeof(Nullable), 401)]
      //  [ProducesResponseType(typeof(Nullable), 403)]
        [HttpGet("{id}", Name = "getOrdersByIdUsingGET")]
        public IActionResult Get(System.Int64 id)
        {

            Console.WriteLine("Get records by id Starting");
            var contents = _fileProvider.GetDirectoryContents("Assets");
            Console.WriteLine("Assets Directory Found" + contents);
            string path = contents.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            string orderListJsonPath = Path.Combine(path, @"orderlist.json");
            Console.WriteLine("Order list file path found" + orderListJsonPath);
            orderListJsonString = System.IO.File.ReadAllText(orderListJsonPath);
            Console.WriteLine("Order list file data found" + orderListJsonPath);
            var jsonObj = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Orders>>(orderListJsonString).Where(o=>o.id ==id.ToString()).Select(a =>a).FirstOrDefault();
            Console.WriteLine("Get records by id Completed" + jsonObj);
            if (jsonObj == null)
            {
                return NotFound();
            }
            Console.WriteLine("Records found");
            return Ok(jsonObj);
        }
        /// <summary>
        /// Method to create an Order.
        /// </summary>
        /// <param name="productArray"></param>
        /// <response code="201">Created</response>
       // [ProducesResponseType(typeof(Orders), 200)]
       // [ProducesResponseType(typeof(Orders), 201)]
       // [ProducesResponseType(typeof(Nullable), 401)]
        [HttpPost(Name = "createOrderUsingPOST")]
         public IActionResult Post([FromBody] ProductArray productArray)
           {
            if (productArray == null)
            {
                return BadRequest();
            }
            List<Product> productsList = productArray.Products.ToList();
            Console.WriteLine("Created Records Starting");
            var assets = _fileProvider.GetDirectoryContents("Assets");
            Console.WriteLine("Assets Directory Found" + assets);
            string path = assets.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            Console.WriteLine("Data Under Assets folder Found" + path);
            string orderListJsonPath = Path.Combine(path, @"orderlist.json");
            Console.WriteLine("order list json file found" + orderListJsonPath);
            orderListJsonString = System.IO.File.ReadAllText(orderListJsonPath);
            Console.WriteLine("order list json file data found" + orderListJsonString);
            var jsonObj = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Orders>>(orderListJsonString);
            
            var orderId = Convert.ToInt64(Newtonsoft.Json.JsonConvert.DeserializeObject<List<Orders>>(orderListJsonString).Last().id) + 4;
            List<Orders> orderList = new List<Orders>();
            Orders orders = new Orders();
            orders.id = orderId.ToString();
            foreach (Product item in productsList)
            {
                if (item.Productnumber != 0)
                {
                    Product product = new Product();
                    product.Productnumber = item.Productnumber;
                    product.Name = item.Name;
                    product.Specification = item.Specification;
                    product.Image = item.Image;
                    product.Price = item.Price;
                    orders.Products.Add(product);
                }
            }

            DateTime date = DateTime.Now;
            orders.CreatedDate = string.Format("{0:s}", date);

            var orderSerializeJsonString = Newtonsoft.Json.JsonConvert.SerializeObject(orders);
            var ordersAppendedList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Orders>>(orderListJsonString).Append(orders);
            var serializeOrderJsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(ordersAppendedList);
            var orderJsonString = Newtonsoft.Json.JsonConvert.DeserializeObject<Orders>(orderSerializeJsonString);
            var  productAssets= _fileProvider.GetDirectoryContents("Assets");
            Console.WriteLine("Assets Directory Found" + productAssets);
            string productAssetsDataPath = productAssets.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            Console.WriteLine("Data Under Assets folder Found" + productAssetsDataPath);
            string productListJsonPath = Path.Combine(productAssetsDataPath, @"productlist.json");
            Console.WriteLine("product list json file found" + productListJsonPath);
           productListJsonString = System.IO.File.ReadAllText(productListJsonPath);
            var productsAppendedList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Product>>(productListJsonString).Append(productsList.FirstOrDefault());
            var serializeProductJsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(productsAppendedList);

           
            var contents = _fileProvider.GetDirectoryContents("Assets");
            Console.WriteLine("Assets Directory Found" + contents);
            string dataFolderJsonPath = contents.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            string orderListJsonPathforWrite = Path.Combine(dataFolderJsonPath, @"orderlist.json");
            System.IO.File.WriteAllText(orderListJsonPathforWrite, serializeOrderJsonstring);
            Console.WriteLine("write data into orderlist file");
            var contentsWriteProduct = _fileProvider.GetDirectoryContents("Assets");
            string dataFolderJsonPathForProduct = contentsWriteProduct.FirstOrDefault(x => x.Name == "Data").PhysicalPath;
            string productListJsonPathforWrite = Path.Combine(dataFolderJsonPath, @"productlist.json");
            System.IO.File.WriteAllText(productListJsonPathforWrite, serializeProductJsonstring);
            Console.WriteLine("write data into productlist file");
            return Created("", orderJsonString);
            
        }
    }
}
